from distutils.core import setup
setup(
  name = 'colorlover',
  packages = ['colorlover'], # this must be the same as the name above
  version = '0.1',
  description = 'Color scales for IPython notebook',
  author = 'Jack Parmer',
  author_email = 'jack@plot.ly',
  url = 'https://github.com/jackparmer/colorlover', # use the URL to the github repo
  download_url = 'https://github.com/jackparmer/colorlover/tarball/0.1', # I'll explain this in a second
  keywords = ['ipython notebook','color scales'], # arbitrary keywords
  classifiers = [],
)
